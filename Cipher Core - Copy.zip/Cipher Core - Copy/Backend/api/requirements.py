from fastapi import APIRouter
from app.services.requirement_analyzer import RequirementAnalyzer

router = APIRouter()

analyzer = RequirementAnalyzer()


@router.post("/analyze")
def analyze_requirements(query: str):
    return analyzer.analyze(query)