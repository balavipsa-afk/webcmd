from fastapi import APIRouter, HTTPException, status

from app.services.scout_pipeline import run_mock_pipeline
from app.services.supabase_service import supabase_service
from schemas.search import (
    SearchCreateRequest,
    SearchCreateResponse,
)


router = APIRouter(
    prefix="/searches",
    tags=["Searches"],
)


@router.post(
    "",
    response_model=SearchCreateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a dataset search",
)
def create_search(
    payload: SearchCreateRequest,
) -> SearchCreateResponse:
    """
    Create a new DataScout search.

    The search is stored in Supabase with status 'created'.
    The returned search_id is used for later pipeline operations.
    """

    try:
        search = supabase_service.create_search(
            query=payload.query,
        )

        return SearchCreateResponse(
            search_id=str(search["id"]),
            status=search.get("status", "created"),
        )

    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not create the search.",
        ) from exc


@router.post(
    "/{search_id}/run",
    summary="Run the DataScout search pipeline",
)
def run_search(search_id: str) -> dict:
    """
    Run the current DataScout pipeline for a search.

    At the moment, this calls the mock pipeline. Later it will call:

    query
    → requirement analyzer
    → browser agent
    → verification
    → ranking
    → Supabase
    """

    try:
        return run_mock_pipeline(search_id)

    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="The search pipeline failed.",
        ) from exc