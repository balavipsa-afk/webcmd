from fastapi import FastAPI
from app.api.requirements import router as requirements_router

app = FastAPI(title="DataScout API")


@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "service": "datascout"
    }


app.include_router(
    requirements_router,
    prefix="/requirements",
    tags=["Requirements"]
)