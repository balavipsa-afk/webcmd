from pydantic import BaseModel, ConfigDict, Field


class CandidateDataset(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "name": "Dataset A",
                "source": "Hugging Face",
                "url": "https://example.com/dataset-a",
                "description": "A multilingual sentiment dataset",
                "domain": "NLP",
                "task": "sentiment classification",
                "modality": "text",
                "samples": 87000,
                "format": "Parquet",
                "languages": ["English", "Hindi", "French"],
                "labels": True,
                "license": "CC BY",
                "documentation": True,
                "accessible": True,
                "verified": True,
                "verification_notes": [],
                "warnings": [],
            }
        }
    )

    name: str = Field(..., min_length=1)
    source: str | None = None
    url: str | None = None
    description: str | None = None
    domain: str | None = None
    task: str | None = None
    modality: str | None = None
    samples: int | None = Field(default=None, ge=0)
    format: str | None = None
    languages: list[str] = Field(default_factory=list)
    labels: bool | None = None
    license: str | None = None
    documentation: bool | None = None
    accessible: bool | None = None
    verified: bool | None = None
    verification_notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class CandidateList(BaseModel):
    candidates: list[CandidateDataset] = Field(default_factory=list)