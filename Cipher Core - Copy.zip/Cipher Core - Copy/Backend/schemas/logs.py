from datetime import datetime, timezone

from pydantic import BaseModel, Field


class AgentLog(BaseModel):
    action: str
    website: str | None = None
    dataset: str | None = None
    message: str
    status: str
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )


class AgentLogResponse(BaseModel):
    logs: list[AgentLog] = Field(default_factory=list)