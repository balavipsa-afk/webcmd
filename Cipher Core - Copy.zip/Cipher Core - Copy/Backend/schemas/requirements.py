from pydantic import BaseModel, ConfigDict, Field


class UserQuery(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "query": (
                    "I need a multilingual sentiment dataset with at least "
                    "50000 labelled samples for commercial use"
                )
            }
        }
    )

    query: str = Field(
        ...,
        min_length=3,
        max_length=5000,
        description="Natural-language dataset request from the user.",
    )


class Requirements(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "domain": "NLP",
                "task": "sentiment classification",
                "modality": "text",
                "minimum_samples": 50000,
                "languages": ["multilingual"],
                "labels_required": True,
                "commercial_use": True,
                "license": None,
            }
        }
    )

    domain: str | None = None
    task: str | None = None
    modality: str | None = None
    minimum_samples: int | None = Field(default=None, ge=0)
    languages: list[str] = Field(default_factory=list)
    labels_required: bool | None = None
    commercial_use: bool | None = None
    license: str | None = None