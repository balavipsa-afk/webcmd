from pydantic import BaseModel, Field


class RankedDataset(BaseModel):
    name: str
    source: str | None = None
    url: str | None = None
    score: float = Field(..., ge=0, le=100)
    reason: str
    matched_criteria: list[str] = Field(default_factory=list)
    failed_criteria: list[str] = Field(default_factory=list)
    verified: bool | None = None
    warnings: list[str] = Field(default_factory=list)


class RejectedDataset(BaseModel):
    name: str
    source: str | None = None
    url: str | None = None
    reason: str
    failed_criteria: list[str] = Field(default_factory=list)
    verified: bool | None = None


class RankingResponse(BaseModel):
    results: list[RankedDataset] = Field(default_factory=list)
    rejected: list[RejectedDataset] = Field(default_factory=list)