from datetime import datetime

from pydantic import BaseModel, Field


class SearchCreateRequest(BaseModel):
    query: str = Field(..., min_length=3, max_length=5000)


class SearchCreateResponse(BaseModel):
    search_id: str
    status: str


class SearchStatusResponse(BaseModel):
    search_id: str
    query: str
    status: str
    created_at: datetime | None = None
    completed_at: datetime | None = None
    error_message: str | None = None