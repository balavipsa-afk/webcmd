class LLMClient:

    def __init__(self):
        pass

    def generate(self, prompt: str) -> str:
        # LLM API call
        pass