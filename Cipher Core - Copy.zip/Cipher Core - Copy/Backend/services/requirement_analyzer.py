from app.schemas.requirements import DatasetRequirement


class RequirementAnalyzer:

    def analyze(self, query: str) -> DatasetRequirement:
        """
        Convert a natural-language dataset request
        into structured dataset requirements.
        """

        return DatasetRequirement(
            query=query,
            domain=None,
            required_columns=[],
            min_rows=None,
            preferred_format=None,
            license_requirement=None
        )