from typing import Any

from app.services.requirement_analyzer import analyze_query
from app.services.supabase_service import supabase_service


def run_mock_pipeline(search_id: str) -> dict[str, Any]:
    """
    Run the current development pipeline.

    Current flow:

    1. Load the search from Supabase.
    2. Analyze the user query.
    3. Save structured requirements.
    4. Create a clearly labelled MOCK activity log.
    5. Mark the search as completed.

    Real browser research will be added later.
    """

    # 1. Find the search
    search = supabase_service.get_search(
        search_id=search_id,
    )

    if not search:
        raise ValueError("Search not found.")

    query = search["query"]

    # 2. Mark the search as analyzing
    supabase_service.update_search_status(
        search_id=search_id,
        status="analyzing",
    )

    # 3. Analyze the user's natural-language query
    requirements = analyze_query(query)

    # 4. Save the structured requirements
    supabase_service.save_requirements(
        search_id=search_id,
        requirements=requirements.model_dump(),
    )

    # 5. Mark the search as scouting
    supabase_service.update_search_status(
        search_id=search_id,
        status="scouting",
    )

    # 6. Add an honest mock activity log
    mock_log = {
        "action": "search",
        "website": "MOCK",
        "dataset": None,
        "message": (
            "Mock browser mode is enabled. "
            "No real browser navigation was performed."
        ),
        "status": "warning",
    }

    supabase_service.save_agent_log(
        search_id=search_id,
        log=mock_log,
    )

    # 7. Mark the current temporary pipeline as completed
    supabase_service.update_search_status(
        search_id=search_id,
        status="completed",
    )

    # 8. Return a response for testing
    return {
        "search_id": search_id,
        "status": "completed",
        "requirements": requirements.model_dump(),
        "candidates": [],
        "message": (
            "Pipeline completed in MOCK mode. "
            "Real browser research has not been performed."
        ),
    }