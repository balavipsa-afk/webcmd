class SupabaseService:

    def __init__(self):
        # initialize Supabase client
        pass

    def save_search(self, data):
        pass

    def save_dataset(self, data):
        pass

    def get_search(self, search_id):
        pass