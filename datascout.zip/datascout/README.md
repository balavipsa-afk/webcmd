# DataScout

Frontend for **DataScout**, an autonomous browser agent that researches
datasets from a natural-language request. This repo is UI-only: it uses
mock data behind a typed service layer, with no real agent or model calls.

## Stack

- Next.js 14 (App Router) + React 18 + TypeScript
- Tailwind CSS
- Framer Motion
- Lucide React icons

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## How it's organized

```
app/
  layout.tsx        Fonts (IBM Plex Sans/Mono), global metadata
  page.tsx           Top-level state machine: landing → scouting → results
  globals.css

components/
  LandingHero.tsx        Branding + natural-language query box + Scout button
  AgentActivity.tsx       Activity screen: animated visualizer + live timeline
  AgentVisualizer.tsx     Animated "digital researcher" radar/scope graphic
  Timeline.tsx            Step-by-step research timeline
  ResultsDashboard.tsx    Ranked results + extracted requirements + rejected list
  DatasetCard.tsx         Individual ranked dataset card
  DatasetModal.tsx        Full dataset detail + "Why this dataset?" explanation
  RejectedDatasets.tsx    Collapsible list of rejected datasets and reasons
  StatusBadge.tsx         Verification / accessibility / documentation badges
  ScopeBackdrop.tsx       Shared background grid/glow

lib/
  types.ts            Shared JSON contracts (ScoutRequest, ScoutResponse, ...)
  api.ts              Service layer — the ONLY module aware of mock vs. real backend
  mock/mockResponse.ts Mock dataset + step data
```

## Swapping in the real backend

`lib/api.ts` is the single seam between the UI and the backend. It currently
returns mock data with `USE_MOCK = true`. To connect the real DataScout
backend:

1. Set `USE_MOCK = false` in `lib/api.ts`.
2. Implement the two API routes it already calls:
   - `POST /api/scout` — body `ScoutRequest`, response `ScoutResponse`
   - `GET /api/datasets/:id` — response `DatasetResult`
3. No component imports mock data directly, so nothing else needs to change.

## About the JSON contract

`lib/types.ts` defines `ScoutRequest`, `ScoutResponse`, `AgentStep`,
`DatasetResult`, `RequirementMatch`, and `RejectedDataset`. No shared
contract file was attached when this project was built, so these types are
a proposed contract kept in one place on purpose — if the team's actual
DataScout contract differs, update `lib/types.ts` and the mock data in
`lib/mock/` to match; every component is typed against `lib/types.ts`, so
a mismatch will fail at compile time instead of silently breaking at
runtime.

## Notes

- All agent behavior (the step timeline, dataset scoring, rejections) is
  mock data simulated with timed delays in `AgentActivity.tsx` and
  `lib/mock/mockResponse.ts` — there is no real search or ranking logic.
- Responsive from mobile up; the activity screen stacks the visualizer
  above the timeline below the `lg` breakpoint.
