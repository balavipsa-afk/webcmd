"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import ScopeBackdrop from "@/components/ScopeBackdrop";
import LandingHero from "@/components/LandingHero";
import AgentActivity from "@/components/AgentActivity";
import ResultsDashboard from "@/components/ResultsDashboard";
import { runScout } from "@/lib/api";
import { ScoutResponse } from "@/lib/types";

type Stage = "landing" | "scouting" | "results";

export default function Home() {
  const [stage, setStage] = useState<Stage>("landing");
  const [query, setQuery] = useState("");
  const [response, setResponse] = useState<ScoutResponse | null>(null);

  async function handleSubmit(q: string) {
    setQuery(q);
    setStage("scouting");
    const res = await runScout({ query: q });
    setResponse(res);
  }

  function handleNewSearch() {
    setStage("landing");
    setResponse(null);
    setQuery("");
  }

  return (
    <main className="relative min-h-screen">
      <ScopeBackdrop />
      <AnimatePresence mode="wait">
        {stage === "landing" && (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <LandingHero onSubmit={handleSubmit} />
          </motion.div>
        )}

        {stage === "scouting" && response && (
          <motion.div
            key="scouting"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AgentActivity
              query={query}
              response={response}
              onDone={() => setStage("results")}
            />
          </motion.div>
        )}

        {stage === "results" && response && (
          <motion.div
            key="results"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ResultsDashboard response={response} onNewSearch={handleNewSearch} />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
