"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import AgentVisualizer from "@/components/AgentVisualizer";
import Timeline from "@/components/Timeline";
import { AgentStep, ScoutResponse } from "@/lib/types";

export default function AgentActivity({
  query,
  response,
  onDone,
}: {
  query: string;
  response: ScoutResponse;
  onDone: () => void;
}) {
  const [steps, setSteps] = useState<AgentStep[]>(
    response.steps.map((s) => ({ ...s, status: "pending" }))
  );
  const doneRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    doneRef.current = false;

    async function run() {
      for (let i = 0; i < response.steps.length; i++) {
        if (cancelled) return;
        setSteps((prev) =>
          prev.map((s, idx) => (idx === i ? { ...s, status: "in_progress" } : s))
        );
        await new Promise((r) => setTimeout(r, response.steps[i].durationMs));
        if (cancelled) return;
        setSteps((prev) =>
          prev.map((s, idx) => (idx === i ? { ...s, status: "complete" } : s))
        );
      }
      if (!cancelled) {
        doneRef.current = true;
        await new Promise((r) => setTimeout(r, 500));
        if (!cancelled) onDone();
      }
    }

    run();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [response]);

  const completedCount = steps.filter((s) => s.status === "complete").length;

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-6 py-16">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="mb-10"
      >
        <p className="font-mono text-[11px] uppercase tracking-wide text-scope/80">
          Scouting in progress
        </p>
        <h2 className="mt-2 max-w-2xl text-xl font-medium text-haze-100 sm:text-2xl">
          &ldquo;{query}&rdquo;
        </h2>
      </motion.div>

      <div className="grid flex-1 grid-cols-1 items-start gap-12 lg:grid-cols-[1fr_1.1fr]">
        <div className="order-2 lg:order-1">
          <AgentVisualizer active={!doneRef.current} />
          <div className="mx-auto mt-8 max-w-xs text-center">
            <p className="font-mono text-xs text-haze-400">
              {completedCount} / {steps.length} steps complete
            </p>
            <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-ink-700">
              <motion.div
                className="h-full rounded-full bg-scope"
                animate={{ width: `${(completedCount / steps.length) * 100}%` }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              />
            </div>
          </div>
        </div>

        <div className="order-1 rounded-2xl border border-ink-700 bg-ink-900/50 p-6 lg:order-2">
          <Timeline steps={steps} />
        </div>
      </div>
    </div>
  );
}
