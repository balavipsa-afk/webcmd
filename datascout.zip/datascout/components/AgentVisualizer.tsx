"use client";

import { motion } from "framer-motion";

export default function AgentVisualizer({ active }: { active: boolean }) {
  return (
    <div className="relative mx-auto flex h-64 w-64 items-center justify-center sm:h-80 sm:w-80">
      {/* pulsing detection rings */}
      {active &&
        [0, 1, 2].map((i) => (
          <span
            key={i}
            className="absolute h-24 w-24 rounded-full border border-scope/40"
            style={{
              animation: "pulseRing 2.6s cubic-bezier(0.2,0.6,0.4,1) infinite",
              animationDelay: `${i * 0.7}s`,
            }}
          />
        ))}

      {/* outer scope ring */}
      <div className="absolute h-56 w-56 rounded-full border border-ink-600 sm:h-72 sm:w-72" />
      <div className="absolute h-44 w-44 rounded-full border border-ink-600/70 sm:h-56 sm:w-56" />

      {/* tick marks */}
      <svg viewBox="0 0 200 200" className="absolute h-56 w-56 sm:h-72 sm:w-72">
        {Array.from({ length: 24 }).map((_, i) => {
          const angle = (i / 24) * 360;
          return (
            <line
              key={i}
              x1="100"
              y1="6"
              x2="100"
              y2={i % 6 === 0 ? "16" : "12"}
              stroke="#374158"
              strokeWidth={i % 6 === 0 ? 1.6 : 1}
              transform={`rotate(${angle} 100 100)`}
            />
          );
        })}
      </svg>

      {/* rotating sweep */}
      <motion.div
        className="absolute h-56 w-56 sm:h-72 sm:w-72"
        animate={active ? { rotate: 360 } : { rotate: 0 }}
        transition={{ duration: 3.4, repeat: active ? Infinity : 0, ease: "linear" }}
      >
        <svg viewBox="0 0 200 200" className="h-full w-full">
          <defs>
            <linearGradient id="sweepGradient" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#3FE0C5" stopOpacity="0" />
              <stop offset="100%" stopColor="#3FE0C5" stopOpacity="0.55" />
            </linearGradient>
          </defs>
          <path d="M100 100 L100 8 A92 92 0 0 1 165 35 Z" fill="url(#sweepGradient)" />
        </svg>
      </motion.div>

      {/* core */}
      <div className="relative flex h-20 w-20 items-center justify-center rounded-full border border-scope/50 bg-ink-900 sm:h-24 sm:w-24">
        <div
          className={`h-3 w-3 rounded-full bg-scope ${active ? "animate-blink" : ""}`}
          style={{ boxShadow: "0 0 18px 4px rgba(63,224,197,0.55)" }}
        />
      </div>

      {/* orbiting scan dot */}
      {active && (
        <motion.div
          className="absolute h-2.5 w-2.5 rounded-full bg-signal"
          style={{ boxShadow: "0 0 10px 2px rgba(255,176,32,0.7)" }}
          animate={{
            x: [0, 96, 0, -96, 0],
            y: [-96, 0, 96, 0, -96],
          }}
          transition={{ duration: 5.2, repeat: Infinity, ease: "easeInOut" }}
        />
      )}
    </div>
  );
}
