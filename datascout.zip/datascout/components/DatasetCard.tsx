"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, Database, Globe2, Tag } from "lucide-react";
import { DatasetResult } from "@/lib/types";
import {
  AccessibilityBadge,
  DocumentationBadge,
  VerificationBadge,
} from "@/components/StatusBadge";

function MatchDial({ value, size }: { value: number; size: number }) {
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#1A2235"
          strokeWidth={4}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#3FE0C5"
          strokeWidth={4}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono text-sm font-semibold text-haze-100">
          {value}%
        </span>
      </div>
    </div>
  );
}

export default function DatasetCard({
  dataset,
  rank,
  featured,
  onOpen,
}: {
  dataset: DatasetResult;
  rank: number;
  featured?: boolean;
  onOpen: () => void;
}) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: rank * 0.05 }}
      className={`group relative rounded-2xl border p-5 transition-colors ${
        featured
          ? "border-scope/40 bg-gradient-to-br from-ink-900 to-ink-800"
          : "border-ink-700 bg-ink-900/50 hover:border-ink-500"
      }`}
    >
      {featured && (
        <span className="absolute -top-3 left-5 rounded-full bg-scope px-2.5 py-0.5 font-mono text-[10px] font-semibold text-ink-950">
          TOP MATCH
        </span>
      )}

      <div className="flex items-start gap-4">
        <MatchDial value={dataset.matchPercentage} size={featured ? 68 : 56} />

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3
              className={`truncate font-medium text-haze-100 ${
                featured ? "text-lg" : "text-base"
              }`}
            >
              {dataset.name}
            </h3>
            <span className="font-mono text-[11px] text-haze-400">
              #{rank + 1} · {dataset.source}
            </span>
          </div>
          <p className="mt-1 line-clamp-2 text-sm text-haze-300">
            {dataset.description}
          </p>

          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-haze-300">
            <span className="inline-flex items-center gap-1.5">
              <Database className="h-3.5 w-3.5 text-haze-400" /> {dataset.size}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Tag className="h-3.5 w-3.5 text-haze-400" /> {dataset.task}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Globe2 className="h-3.5 w-3.5 text-haze-400" />
              {dataset.language.join(", ")}
            </span>
          </div>

          <div className="mt-3 flex flex-wrap gap-1.5">
            {dataset.modality.map((m) => (
              <span
                key={m}
                className="rounded-md bg-ink-700 px-2 py-0.5 text-[11px] text-haze-200"
              >
                {m}
              </span>
            ))}
            {dataset.labels.map((l) => (
              <span
                key={l}
                className="rounded-md border border-ink-600 px-2 py-0.5 text-[11px] text-haze-300"
              >
                {l}
              </span>
            ))}
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <VerificationBadge status={dataset.verification} />
            <AccessibilityBadge status={dataset.accessibility} />
            <DocumentationBadge status={dataset.documentation} />
            <span className="rounded-md border border-ink-600 px-2 py-1 font-mono text-[11px] text-haze-300">
              {dataset.license}
            </span>
          </div>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-ink-700 pt-3">
        <button
          onClick={onOpen}
          className="text-sm font-medium text-scope transition-colors hover:text-scope/80"
        >
          Why this dataset?
        </button>
        <a
          href={dataset.url}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 text-xs text-haze-400 transition-colors hover:text-haze-100"
        >
          Open source
          <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      </div>
    </motion.div>
  );
}
