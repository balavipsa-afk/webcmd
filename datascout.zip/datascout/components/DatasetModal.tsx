"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Check, X, XCircle } from "lucide-react";
import { DatasetResult } from "@/lib/types";
import {
  AccessibilityBadge,
  DocumentationBadge,
  VerificationBadge,
} from "@/components/StatusBadge";

export default function DatasetModal({
  dataset,
  onClose,
}: {
  dataset: DatasetResult | null;
  onClose: () => void;
}) {
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <AnimatePresence>
      {dataset && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center bg-ink-950/80 backdrop-blur-sm sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={`${dataset.name} details`}
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl border border-ink-700 bg-ink-900 p-6 shadow-2xl sm:rounded-2xl sm:p-8"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono text-[11px] text-haze-400">
                  {dataset.source} · {dataset.task}
                </p>
                <h2 className="mt-1 text-xl font-semibold text-haze-100">
                  {dataset.name}
                </h2>
              </div>
              <button
                onClick={onClose}
                aria-label="Close"
                className="rounded-lg border border-ink-700 p-1.5 text-haze-400 transition-colors hover:text-haze-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="mt-4 text-sm leading-relaxed text-haze-300">
              {dataset.description}
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-2">
              <VerificationBadge status={dataset.verification} />
              <AccessibilityBadge status={dataset.accessibility} />
              <DocumentationBadge status={dataset.documentation} />
            </div>

            <div className="mt-6 grid grid-cols-2 gap-x-6 gap-y-4 rounded-xl border border-ink-700 bg-ink-950/40 p-4 sm:grid-cols-3">
              <Field label="Match" value={`${dataset.matchPercentage}%`} />
              <Field label="Size" value={dataset.size} />
              <Field label="License" value={dataset.license} />
              <Field label="Modality" value={dataset.modality.join(", ")} />
              <Field label="Language" value={dataset.language.join(", ")} />
              <Field label="Labels" value={dataset.labels.join(", ")} />
              {Object.entries(dataset.metadata).map(([k, v]) => (
                <Field key={k} label={k} value={v} />
              ))}
            </div>

            <div className="mt-7">
              <h3 className="text-sm font-medium text-haze-100">
                Why this dataset?
              </h3>
              <ul className="mt-3 space-y-2.5">
                {dataset.requirementsMatched.map((r, i) => (
                  <li key={i} className="flex gap-2.5 text-sm">
                    {r.matched ? (
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-scope" />
                    ) : (
                      <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-flag" />
                    )}
                    <div>
                      <p className="text-haze-100">{r.requirement}</p>
                      <p className="mt-0.5 text-xs text-haze-400">
                        {r.explanation}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <a
              href={dataset.url}
              target="_blank"
              rel="noreferrer"
              className="mt-8 inline-flex items-center gap-2 rounded-xl bg-scope px-4 py-2.5 text-sm font-medium text-ink-950 transition-colors hover:bg-scope/90"
            >
              Open dataset source
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <p className="font-mono text-[10px] uppercase tracking-wide text-haze-400">
        {label}
      </p>
      <p className="mt-0.5 truncate text-sm text-haze-100">{value}</p>
    </div>
  );
}
