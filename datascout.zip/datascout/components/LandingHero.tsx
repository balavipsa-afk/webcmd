"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Compass } from "lucide-react";

const EXAMPLES = [
  "Street-scene images with segmentation masks, commercial license",
  "Multilingual customer support tickets for intent classification",
  "Time-series sensor data for predictive maintenance",
];

export default function LandingHero({
  onSubmit,
}: {
  onSubmit: (query: string) => void;
}) {
  const [query, setQuery] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim().length === 0) return;
    onSubmit(query.trim());
  }

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-3xl flex-col items-center justify-center px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="mb-8 flex items-center gap-2.5 rounded-full border border-ink-600 bg-ink-900/60 px-4 py-1.5"
      >
        <Compass className="h-3.5 w-3.5 text-scope" strokeWidth={2} />
        <span className="font-mono text-[11px] tracking-wide text-haze-300">
          autonomous dataset research agent
        </span>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.05, ease: "easeOut" }}
        className="text-center text-4xl font-semibold leading-[1.1] text-haze-100 sm:text-5xl"
      >
        Data<span className="text-scope">Scout</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}
        className="mt-4 max-w-lg text-center text-base text-haze-300"
      >
        Describe the dataset you need. DataScout searches Hugging Face,
        Kaggle, and GitHub, checks license and access, and hands back a
        ranked shortlist with its reasoning shown.
      </motion.p>

      <motion.form
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15, ease: "easeOut" }}
        onSubmit={handleSubmit}
        className="mt-10 w-full"
      >
        <div className="rounded-2xl border border-ink-600 bg-ink-900/70 p-2 shadow-[0_0_0_1px_rgba(63,224,197,0.04)] backdrop-blur transition-colors focus-within:border-scope/60">
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="What dataset are you looking for?"
            rows={3}
            className="w-full resize-none bg-transparent px-4 py-3 text-base text-haze-100 placeholder:text-haze-400 focus:outline-none"
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                handleSubmit(e);
              }
            }}
          />
          <div className="flex items-center justify-between px-3 pb-2 pt-1">
            <span className="font-mono text-[11px] text-haze-400">
              enter to scout · shift+enter for a new line
            </span>
            <button
              type="submit"
              disabled={query.trim().length === 0}
              className="group inline-flex items-center gap-2 rounded-xl bg-scope px-4 py-2 text-sm font-medium text-ink-950 transition-all hover:bg-scope/90 disabled:cursor-not-allowed disabled:bg-ink-600 disabled:text-haze-400"
            >
              Scout Datasets
              <ArrowRight
                className="h-4 w-4 transition-transform group-hover:translate-x-0.5"
                strokeWidth={2.2}
              />
            </button>
          </div>
        </div>
      </motion.form>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.25 }}
        className="mt-6 flex flex-wrap justify-center gap-2"
      >
        {EXAMPLES.map((ex) => (
          <button
            key={ex}
            onClick={() => setQuery(ex)}
            className="rounded-full border border-ink-700 px-3 py-1.5 text-xs text-haze-300 transition-colors hover:border-scope/50 hover:text-haze-100"
          >
            {ex}
          </button>
        ))}
      </motion.div>
    </div>
  );
}
