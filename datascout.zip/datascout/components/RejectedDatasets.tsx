"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, XCircle } from "lucide-react";
import { RejectedDataset } from "@/lib/types";

export default function RejectedDatasets({
  rejected,
}: {
  rejected: RejectedDataset[];
}) {
  const [open, setOpen] = useState(false);

  if (rejected.length === 0) return null;

  return (
    <div className="rounded-2xl border border-ink-700 bg-ink-900/30">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-5 py-4 text-left"
      >
        <div className="flex items-center gap-2.5">
          <XCircle className="h-4 w-4 text-flag" strokeWidth={2} />
          <span className="text-sm font-medium text-haze-100">
            Rejected datasets
          </span>
          <span className="rounded-full bg-ink-700 px-2 py-0.5 font-mono text-[11px] text-haze-300">
            {rejected.length}
          </span>
        </div>
        <ChevronDown
          className={`h-4 w-4 text-haze-400 transition-transform ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <ul className="divide-y divide-ink-700 border-t border-ink-700">
              {rejected.map((r) => (
                <li key={r.id} className="px-5 py-4">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="text-sm font-medium text-haze-100">
                      {r.name}
                    </span>
                    <span className="font-mono text-[11px] text-haze-400">
                      {r.source}
                    </span>
                  </div>
                  <ul className="mt-2 space-y-1">
                    {r.reasons.map((reason, i) => (
                      <li
                        key={i}
                        className="flex gap-2 text-sm text-haze-300"
                      >
                        <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-flag" />
                        {reason}
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
