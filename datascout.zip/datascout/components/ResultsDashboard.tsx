"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ListChecks } from "lucide-react";
import { ScoutResponse } from "@/lib/types";
import DatasetCard from "@/components/DatasetCard";
import RejectedDatasets from "@/components/RejectedDatasets";
import DatasetModal from "@/components/DatasetModal";

export default function ResultsDashboard({
  response,
  onNewSearch,
}: {
  response: ScoutResponse;
  onNewSearch: () => void;
}) {
  const [openId, setOpenId] = useState<string | null>(null);
  const openDataset = response.results.find((d) => d.id === openId) ?? null;

  return (
    <div className="mx-auto w-full max-w-4xl px-6 py-16">
      <div className="flex items-center justify-between">
        <button
          onClick={onNewSearch}
          className="inline-flex items-center gap-1.5 text-sm text-haze-400 transition-colors hover:text-haze-100"
        >
          <ArrowLeft className="h-4 w-4" /> New search
        </button>
        <span className="font-mono text-[11px] text-haze-400">
          {response.results.length} matches · {response.rejected.length} rejected
        </span>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mt-6"
      >
        <p className="font-mono text-[11px] uppercase tracking-wide text-scope/80">
          Scout results for
        </p>
        <h1 className="mt-2 text-2xl font-semibold text-haze-100 sm:text-3xl">
          &ldquo;{response.query}&rdquo;
        </h1>
        <p className="mt-3 max-w-2xl text-sm text-haze-300">{response.summary}</p>
      </motion.div>

      <div className="mt-6 rounded-2xl border border-ink-700 bg-ink-900/40 p-5">
        <div className="flex items-center gap-2">
          <ListChecks className="h-4 w-4 text-scope" strokeWidth={2} />
          <h2 className="text-sm font-medium text-haze-100">
            Requirements extracted from your request
          </h2>
        </div>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2">
          {response.requirements.map((req, i) => (
            <li
              key={i}
              className="rounded-lg border border-ink-700 bg-ink-950/40 px-3 py-2 text-xs text-haze-300"
            >
              {req}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-8 space-y-4">
        {response.results.map((dataset, i) => (
          <DatasetCard
            key={dataset.id}
            dataset={dataset}
            rank={i}
            featured={i === 0}
            onOpen={() => setOpenId(dataset.id)}
          />
        ))}
      </div>

      <div className="mt-8">
        <RejectedDatasets rejected={response.rejected} />
      </div>

      <DatasetModal dataset={openDataset} onClose={() => setOpenId(null)} />
    </div>
  );
}
