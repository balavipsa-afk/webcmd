export default function ScopeBackdrop() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink-950">
      <div className="absolute inset-0 bg-grid-scan bg-grid-lg opacity-40 [mask-image:radial-gradient(ellipse_80%_60%_at_50%_0%,black,transparent)]" />
      <div className="absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-scope/10 blur-[140px]" />
      <div className="absolute bottom-[-200px] right-[-120px] h-[420px] w-[420px] rounded-full bg-signal/5 blur-[130px]" />
    </div>
  );
}
