import {
  BadgeCheck,
  CircleAlert,
  FileCheck2,
  FileQuestion,
  FileX2,
  Lock,
  ShieldAlert,
  Unlock,
} from "lucide-react";
import {
  AccessibilityStatus,
  DocumentationStatus,
  VerificationStatus,
} from "@/lib/types";

const base =
  "inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium font-mono";

export function VerificationBadge({ status }: { status: VerificationStatus }) {
  if (status === "verified")
    return (
      <span className={`${base} bg-scope/10 text-scope`}>
        <BadgeCheck className="h-3.5 w-3.5" strokeWidth={2} /> verified
      </span>
    );
  if (status === "flagged")
    return (
      <span className={`${base} bg-flag/10 text-flag`}>
        <ShieldAlert className="h-3.5 w-3.5" strokeWidth={2} /> flagged
      </span>
    );
  return (
    <span className={`${base} bg-ink-700 text-haze-300`}>
      <CircleAlert className="h-3.5 w-3.5" strokeWidth={2} /> unverified
    </span>
  );
}

export function AccessibilityBadge({ status }: { status: AccessibilityStatus }) {
  if (status === "public")
    return (
      <span className={`${base} bg-scope/10 text-scope`}>
        <Unlock className="h-3.5 w-3.5" strokeWidth={2} /> public
      </span>
    );
  if (status === "restricted")
    return (
      <span className={`${base} bg-flag/10 text-flag`}>
        <Lock className="h-3.5 w-3.5" strokeWidth={2} /> restricted
      </span>
    );
  return (
    <span className={`${base} bg-signal/10 text-signal`}>
      <Lock className="h-3.5 w-3.5" strokeWidth={2} /> gated
    </span>
  );
}

export function DocumentationBadge({ status }: { status: DocumentationStatus }) {
  if (status === "complete")
    return (
      <span className={`${base} bg-scope/10 text-scope`}>
        <FileCheck2 className="h-3.5 w-3.5" strokeWidth={2} /> complete docs
      </span>
    );
  if (status === "missing")
    return (
      <span className={`${base} bg-flag/10 text-flag`}>
        <FileX2 className="h-3.5 w-3.5" strokeWidth={2} /> missing docs
      </span>
    );
  return (
    <span className={`${base} bg-signal/10 text-signal`}>
      <FileQuestion className="h-3.5 w-3.5" strokeWidth={2} /> partial docs
    </span>
  );
}
