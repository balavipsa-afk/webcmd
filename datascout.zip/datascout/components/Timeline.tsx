"use client";

import { AgentStep } from "@/lib/types";
import { CheckCircle2, CircleDashed, Loader2, XCircle } from "lucide-react";
import { motion } from "framer-motion";

function StepIcon({ status }: { status: AgentStep["status"] }) {
  if (status === "complete")
    return <CheckCircle2 className="h-5 w-5 text-scope" strokeWidth={2} />;
  if (status === "in_progress")
    return <Loader2 className="h-5 w-5 animate-spin text-signal" strokeWidth={2} />;
  if (status === "failed")
    return <XCircle className="h-5 w-5 text-flag" strokeWidth={2} />;
  return <CircleDashed className="h-5 w-5 text-ink-500" strokeWidth={2} />;
}

export default function Timeline({ steps }: { steps: AgentStep[] }) {
  return (
    <ol className="relative">
      {steps.map((step, i) => {
        const isLast = i === steps.length - 1;
        return (
          <li key={step.id} className="relative flex gap-4 pb-7 last:pb-0">
            {!isLast && (
              <span
                className={`absolute left-[10px] top-6 h-full w-px ${
                  step.status === "complete" ? "bg-scope/50" : "bg-ink-600"
                }`}
              />
            )}
            <div className="z-10 mt-0.5 shrink-0 rounded-full bg-ink-950">
              <StepIcon status={step.status} />
            </div>
            <div className="min-w-0 flex-1">
              <p
                className={`text-sm font-medium leading-6 ${
                  step.status === "pending" ? "text-haze-400" : "text-haze-100"
                }`}
              >
                {step.label}
              </p>
              {step.status !== "pending" && step.detail && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25 }}
                  className="mt-0.5 truncate font-mono text-xs text-haze-400"
                >
                  {step.detail}
                </motion.p>
              )}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
