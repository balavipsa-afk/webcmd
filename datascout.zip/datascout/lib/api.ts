import { AgentStep, DatasetResult, ScoutRequest, ScoutResponse } from "@/lib/types";
import { buildMockResponse } from "@/lib/mock/mockResponse";

/**
 * DataScout API layer.
 *
 * This is the ONLY module that should know whether results come from mock
 * data or a real backend. Every component calls the functions below and
 * never touches lib/mock directly. Swapping to a live backend later should
 * mean rewriting the bodies of these two functions (e.g. to `fetch("/api/scout")`)
 * without touching any component.
 */

const USE_MOCK = true;
const SIMULATED_LATENCY_MS = 400;

function delay<T>(value: T, ms: number): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms));
}

/**
 * Kicks off a scout run for a natural-language dataset request.
 * Returns the full response (steps, results, rejections) up front; the UI
 * is responsible for animating through `steps` to simulate live progress.
 */
export async function runScout(request: ScoutRequest): Promise<ScoutResponse> {
  if (!USE_MOCK) {
    const res = await fetch("/api/scout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    if (!res.ok) {
      throw new Error(`Scout request failed: ${res.status}`);
    }
    return res.json();
  }

  return delay(buildMockResponse(request.query), SIMULATED_LATENCY_MS);
}

/**
 * Fetches a single dataset's full detail record by id. In mock mode this
 * looks the id up in the last-run mock response set.
 */
export async function getDatasetById(
  id: string,
  fromResults: DatasetResult[]
): Promise<DatasetResult | undefined> {
  if (!USE_MOCK) {
    const res = await fetch(`/api/datasets/${id}`);
    if (!res.ok) return undefined;
    return res.json();
  }
  return delay(
    fromResults.find((d) => d.id === id),
    120
  );
}

export type { AgentStep };
