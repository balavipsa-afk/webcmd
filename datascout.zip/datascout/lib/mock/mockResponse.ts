import { AgentStep, ScoutResponse } from "@/lib/types";

export const MOCK_STEPS: AgentStep[] = [
  {
    id: "understand",
    label: "Understanding Requirements",
    status: "pending",
    detail: "Parsing query into scope, modality, and constraints",
    durationMs: 1100,
  },
  {
    id: "hf",
    label: "Searching Hugging Face",
    status: "pending",
    detail: "Querying datasets hub for candidate matches",
    durationMs: 1400,
  },
  {
    id: "kaggle",
    label: "Checking Kaggle",
    status: "pending",
    detail: "Cross-referencing competition and public datasets",
    durationMs: 1300,
  },
  {
    id: "github",
    label: "Searching GitHub",
    status: "pending",
    detail: "Scanning repos and dataset release pages",
    durationMs: 1200,
  },
  {
    id: "inspect",
    label: "Inspecting Dataset",
    status: "pending",
    detail: "Sampling records and validating schema",
    durationMs: 1500,
  },
  {
    id: "license",
    label: "Checking License",
    status: "pending",
    detail: "Confirming usage terms against your intended use",
    durationMs: 900,
  },
  {
    id: "access",
    label: "Verifying Accessibility",
    status: "pending",
    detail: "Testing download links and gated-access requirements",
    durationMs: 1000,
  },
  {
    id: "metadata",
    label: "Checking Metadata",
    status: "pending",
    detail: "Reviewing documentation, labels, and provenance",
    durationMs: 1000,
  },
  {
    id: "rank",
    label: "Ranking Results",
    status: "pending",
    detail: "Scoring candidates against extracted requirements",
    durationMs: 1100,
  },
];

export function buildMockResponse(query: string): ScoutResponse {
  return {
    query,
    requirements: [
      "Image modality with bounding-box or segmentation labels",
      "Permissive license suitable for commercial use",
      "At least 10,000 labeled samples",
      "Publicly accessible without a gated request",
      "English-language metadata and documentation",
    ],
    steps: MOCK_STEPS,
    summary:
      "Found 3 strong matches across Hugging Face and Kaggle. 4 candidates were rejected for license or accessibility issues.",
    results: [
      {
        id: "ds-01",
        name: "OpenStreet Object Segments",
        description:
          "Street-level imagery with pixel-accurate segmentation masks across 42 urban object classes, collected from open municipal camera programs.",
        matchPercentage: 96,
        size: "18.4 GB",
        modality: ["Image", "Segmentation Mask"],
        language: ["English"],
        labels: ["42 classes", "Polygon masks"],
        task: "Semantic Segmentation",
        license: "CC-BY 4.0",
        source: "Hugging Face",
        verification: "verified",
        accessibility: "public",
        documentation: "complete",
        url: "https://huggingface.co/datasets/openstreet-object-segments",
        requirementsMatched: [
          {
            requirement: "Image modality with bounding-box or segmentation labels",
            matched: true,
            explanation: "Ships dense pixel-level segmentation masks for every image.",
          },
          {
            requirement: "Permissive license suitable for commercial use",
            matched: true,
            explanation: "CC-BY 4.0 permits commercial use with attribution.",
          },
          {
            requirement: "At least 10,000 labeled samples",
            matched: true,
            explanation: "Contains 84,200 labeled frames.",
          },
          {
            requirement: "Publicly accessible without a gated request",
            matched: true,
            explanation: "Direct download, no access request needed.",
          },
          {
            requirement: "English-language metadata and documentation",
            matched: true,
            explanation: "Dataset card and field docs are written in English.",
          },
        ],
        metadata: {
          "Last updated": "2026-06-02",
          Maintainer: "Open Civic Data Collective",
          Format: "WebDataset (tar shards)",
          Citations: "312",
        },
      },
      {
        id: "ds-02",
        name: "UrbanScenes-10K",
        description:
          "Curated bounding-box dataset of vehicles, pedestrians, and signage across 10 cities, built for autonomous-driving perception research.",
        matchPercentage: 89,
        size: "6.1 GB",
        modality: ["Image", "Bounding Box"],
        language: ["English"],
        labels: ["12 classes", "Bounding boxes"],
        task: "Object Detection",
        license: "Apache 2.0",
        source: "Kaggle",
        verification: "verified",
        accessibility: "public",
        documentation: "partial",
        url: "https://kaggle.com/datasets/urbanscenes-10k",
        requirementsMatched: [
          {
            requirement: "Image modality with bounding-box or segmentation labels",
            matched: true,
            explanation: "Provides bounding-box annotations for 12 object classes.",
          },
          {
            requirement: "Permissive license suitable for commercial use",
            matched: true,
            explanation: "Apache 2.0 allows commercial use and modification.",
          },
          {
            requirement: "At least 10,000 labeled samples",
            matched: true,
            explanation: "Exactly 10,000 annotated images across 10 cities.",
          },
          {
            requirement: "Publicly accessible without a gated request",
            matched: true,
            explanation: "Downloadable directly from Kaggle, no approval step.",
          },
          {
            requirement: "English-language metadata and documentation",
            matched: false,
            explanation: "README is written in English but field-level docs are incomplete.",
          },
        ],
        metadata: {
          "Last updated": "2026-04-18",
          Maintainer: "TU Transport Vision Lab",
          Format: "COCO JSON + JPEG",
          Citations: "128",
        },
      },
      {
        id: "ds-03",
        name: "SignageNet Lite",
        description:
          "Lightweight subset of road-sign and storefront signage images with bounding boxes, intended for quick prototyping.",
        matchPercentage: 78,
        size: "740 MB",
        modality: ["Image", "Bounding Box"],
        language: ["English", "German"],
        labels: ["8 classes", "Bounding boxes"],
        task: "Object Detection",
        license: "CC-BY-NC 4.0",
        source: "GitHub",
        verification: "verified",
        accessibility: "public",
        documentation: "complete",
        url: "https://github.com/signagenet/signagenet-lite",
        requirementsMatched: [
          {
            requirement: "Image modality with bounding-box or segmentation labels",
            matched: true,
            explanation: "Bounding boxes provided for 8 signage classes.",
          },
          {
            requirement: "Permissive license suitable for commercial use",
            matched: false,
            explanation: "CC-BY-NC 4.0 restricts the dataset to non-commercial use.",
          },
          {
            requirement: "At least 10,000 labeled samples",
            matched: false,
            explanation: "Only 3,400 labeled images in the lite subset.",
          },
          {
            requirement: "Publicly accessible without a gated request",
            matched: true,
            explanation: "Hosted directly in the repository release assets.",
          },
          {
            requirement: "English-language metadata and documentation",
            matched: true,
            explanation: "Documentation is bilingual, with English as primary.",
          },
        ],
        metadata: {
          "Last updated": "2025-11-30",
          Maintainer: "signagenet (community)",
          Format: "YOLO txt + JPEG",
          Citations: "19",
        },
      },
    ],
    rejected: [
      {
        id: "rej-01",
        name: "MetroVision Full",
        source: "Hugging Face",
        url: "https://huggingface.co/datasets/metrovision-full",
        reasons: [
          "Requires a gated access request with manual approval",
          "License terms are unclear about commercial redistribution",
        ],
      },
      {
        id: "rej-02",
        name: "CitySign Archive 2019",
        source: "Kaggle",
        url: "https://kaggle.com/datasets/citysign-archive-2019",
        reasons: [
          "Last updated in 2019; links to source images now return 404s",
          "Only 2,100 labeled samples, below the 10,000 threshold",
        ],
      },
      {
        id: "rej-03",
        name: "streetobjects-raw",
        source: "GitHub",
        url: "https://github.com/example/streetobjects-raw",
        reasons: [
          "No license file present in the repository",
          "Images are unlabeled; would require manual annotation",
        ],
      },
      {
        id: "rej-04",
        name: "PedCross Benchmark",
        source: "Hugging Face",
        reasons: [
          "Restricted to academic/research use only, excludes commercial use",
          "Documentation is only available in Japanese",
        ],
      },
    ],
  };
}
