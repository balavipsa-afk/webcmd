/**
 * DataScout shared JSON contracts.
 *
 * NOTE: No shared contract file was attached to this task, so the shapes
 * below are a proposed contract, isolated in this one file. If the team's
 * actual DataScout contract differs, update the interfaces here — every
 * component and the mock data in lib/mock/ are typed against them, so a
 * mismatch will surface at compile time rather than silently breaking.
 */

/** A single natural-language dataset request. */
export interface ScoutRequest {
  query: string;
}

export type StepStatus = "pending" | "in_progress" | "complete" | "failed";

/** One step in the agent's live research timeline. */
export interface AgentStep {
  id: string;
  label: string;
  status: StepStatus;
  /** Short line of telemetry shown once the step is running or done. */
  detail?: string;
  /** Roughly how long this step takes to simulate, in milliseconds. */
  durationMs: number;
}

export type VerificationStatus = "verified" | "unverified" | "flagged";
export type AccessibilityStatus = "public" | "gated" | "restricted";
export type DocumentationStatus = "complete" | "partial" | "missing";

/** One requirement extracted from the user's query, and whether a dataset met it. */
export interface RequirementMatch {
  requirement: string;
  matched: boolean;
  explanation: string;
}

/** A dataset the agent found and scored against the request. */
export interface DatasetResult {
  id: string;
  name: string;
  description: string;
  matchPercentage: number;
  size: string;
  modality: string[];
  language: string[];
  labels: string[];
  task: string;
  license: string;
  source: string;
  verification: VerificationStatus;
  accessibility: AccessibilityStatus;
  documentation: DocumentationStatus;
  url: string;
  requirementsMatched: RequirementMatch[];
  metadata: Record<string, string>;
}

/** A dataset the agent considered and ruled out. */
export interface RejectedDataset {
  id: string;
  name: string;
  source: string;
  url?: string;
  reasons: string[];
}

/** Full response for a scout run. */
export interface ScoutResponse {
  query: string;
  requirements: string[];
  steps: AgentStep[];
  results: DatasetResult[];
  rejected: RejectedDataset[];
  summary: string;
}
