import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#05070C",
          900: "#0A0E17",
          800: "#111726",
          700: "#1A2235",
          600: "#242E45",
          500: "#374158",
        },
        haze: {
          400: "#6B7893",
          300: "#8D98AF",
          200: "#B7C0D2",
          100: "#E6EAF2",
        },
        signal: {
          DEFAULT: "#FFB020",
          dim: "#8A5E1F",
          glow: "#FFD180",
        },
        scope: {
          DEFAULT: "#3FE0C5",
          dim: "#1F6E63",
        },
        flag: {
          DEFAULT: "#FF5D5D",
          dim: "#7A2E2E",
        },
      },
      fontFamily: {
        sans: ["var(--font-plex-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-plex-mono)", "ui-monospace", "monospace"],
      },
      backgroundImage: {
        "grid-scan":
          "linear-gradient(rgba(63,224,197,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(63,224,197,0.06) 1px, transparent 1px)",
      },
      backgroundSize: {
        "grid-lg": "48px 48px",
      },
      keyframes: {
        sweep: {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
        blink: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.25" },
        },
        rise: {
          "0%": { transform: "translateY(6px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
        pulseRing: {
          "0%": { transform: "scale(0.8)", opacity: "0.6" },
          "100%": { transform: "scale(1.8)", opacity: "0" },
        },
      },
      animation: {
        sweep: "sweep 4s linear infinite",
        blink: "blink 1.6s ease-in-out infinite",
        rise: "rise 0.4s ease-out both",
        pulseRing: "pulseRing 2.2s cubic-bezier(0.2,0.6,0.4,1) infinite",
      },
    },
  },
  plugins: [],
};
export default config;
